document.addEventListener('DOMContentLoaded', () => {
   
    const btnGeneratore = document.getElementById('btnGeneratore');
    const btnLibreria = document.getElementById('btnLibreria');
    const generatore = document.getElementById('generatore');
    const libreria = document.getElementById('libreria');
    const btnGeneraRicetta = document.getElementById('btnGeneraRicetta');
    const ricettaCasuale = document.getElementById('ricettaCasuale');
    const listaRicette = document.getElementById('listaRicette');
    const ricercaInput = document.createElement('input');
    const filtroSelect = document.createElement('select');
    const porzioniInput = document.createElement('input');

    ricercaInput.type = 'text';
    ricercaInput.placeholder = 'Cerca ricette...';
    ricercaInput.classList.add('ricerca-input');

    filtroSelect.innerHTML = `
        <option value="all">Tutte le difficoltà</option>
        <option value="Molto facile">Molto facile</option>
        <option value="Facile">Facile</option>
        <option value="Media">Media</option>
        <option value="Difficile">Difficile</option>
    `;
    filtroSelect.classList.add('filtro-select');

    porzioniInput.type = 'number';
    porzioniInput.min = '1';
    porzioniInput.value = '4';
    porzioniInput.classList.add('porzioni-input');

    libreria.insertBefore(filtroSelect, listaRicette);
    libreria.insertBefore(ricercaInput, filtroSelect);
    generatore.insertBefore(porzioniInput, btnGeneraRicetta);

    btnGeneratore.addEventListener('click', () => {
        generatore.classList.remove('nascondi');
        libreria.classList.add('nascondi');
    });

    btnLibreria.addEventListener('click', () => {
        libreria.classList.remove('nascondi');
        generatore.classList.add('nascondi');
        mostraLibreriaRicette();
    });

    btnGeneraRicetta.addEventListener('click', () => generaRicettaCasuale(parseInt(porzioniInput.value)));

    ricercaInput.addEventListener('input', mostraLibreriaRicette);
    filtroSelect.addEventListener('change', mostraLibreriaRicette);

 
const ricette = [
    {
        nome: 'Insalata Caprese',
        categoria: 'Primi piatti',
        ingredienti: [
            {nome: 'mozzarella fresca', quantita: 125, unita: 'g'},
            {nome: 'pomodori maturi', quantita: 1, unita: ''},
            {nome: 'basilico fresco', quantita: 3, unita: 'foglie'},
            {nome: 'olio extravergine d\'oliva', quantita: 1, unita: 'cucchiaio'},
            {nome: 'sale', quantita: 1, unita: 'pizzico'},
            {nome: 'pepe nero', quantita: 1, unita: 'pizzico'}
        ],
        immagine: 'https://i0.wp.com/www.piccolericette.net/piccolericette/wp-content/uploads/2018/07/3621_Insalata.jpg?zoom=1.25&resize=595%2C410&ssl=1',
        preparazione: [
            'Lavare e affettare i pomodori.',
            'Tagliare la mozzarella a fette dello stesso spessore dei pomodori.',
            'Su un piatto da portata, alternare fette di pomodoro e mozzarella.',
            'Distribuire le foglie di basilico tra le fette.',
            'Condire con olio d\'oliva, sale e pepe nero macinato al momento.',
            'Lasciar riposare per 10 minuti prima di servire per far amalgamare i sapori.'
        ],
        tempoPreparazione: 15,
        difficolta: 'Molto facile',
        calorie: 250
    },
    {
        nome: 'Pasta al Pomodoro',
        categoria: 'Primi piatti',
        ingredienti: [
            {nome: 'pasta', quantita: 100, unita: 'g'},
            {nome: 'pomodori pelati', quantita: 100, unita: 'g'},
            {nome: 'aglio', quantita: 0.5, unita: 'spicchio'},
            {nome: 'basilico fresco', quantita: 2, unita: 'foglie'},
            {nome: 'olio d\'oliva', quantita: 1, unita: 'cucchiaio'},
            {nome: 'sale', quantita: 1, unita: 'pizzico'},
            {nome: 'pepe', quantita: 1, unita: 'pizzico'}
        ],
        immagine: 'https://www.giallozafferano.it/images/221-22163/Spaghetti-al-pomodoro_450x300.jpg',
        preparazione: [
            'In una padella, scaldare l\'olio e soffriggere l\'aglio schiacciato.',
            'Aggiungere i pomodori pelati e cuocere a fuoco medio per 15-20 minuti.',
            'Nel frattempo, cuocere la pasta in acqua salata secondo le istruzioni sulla confezione.',
            'Aggiungere il basilico spezzettato alla salsa e aggiustare di sale e pepe.',
            'Scolare la pasta e mescolarla con la salsa.',
            'Servire con basilico fresco e un filo d\'olio d\'oliva.'
        ],
        tempoPreparazione: 25,
        difficolta: 'Facile',
        calorie: 350
    },
    {
        nome: 'Cotoletta alla milanese',
        categoria: 'Secondi piatti',
        ingredienti: [
            {nome: 'Costolette di vitello', quantita: 98, unita: 'g'},
            {nome: 'Pangrattato', quantita: 50, unita: 'g'},
            {nome: 'Uova', quantita: 2, unita: ''},
            {nome: 'Sale fino', quantita: 1, unita: 'g'},
            {nome: 'Burro', quantita: 200, unita: 'g'},
            {nome: 'patate fritte', quantita: 250, unita: 'g'},
        ],
        immagine: 'https://www.giallozafferano.it/images/265-26509/Cotoletta-alla-milanese-della-nonna_450x300.jpg',
        preparazione: [
            'Per realizzare la cotoletta alla milanese della nonna adagiate la costoletta di vitello su un tagliere,coprite con un foglio di carta forno e battete delicatamente con un batticarne fino a raggiungere lo spessore desiderato.',
            'In una ciotola condite le uova con il sale e sbattetele con una frusta . Versate le uova sbattute in un vassoio abbastanza grande da contenere la carne . Distribuite il pangrattato in un secondo vassoio.',
            'Passate la carne prima nelle uove e poi nel pangrattato, ricoprendo bene entrambi i lati. Fate sciogliere il burro chiarificato in una padella capiente .',
            'Adagiate la cotoletta e friggetela fino a quando sarà bella dorata da entrambi i lati, girandola con delle pinze da cucina; il tempo di cottura dipende dallo spessore della carne. Salate a piacere e servite subito la vostra cotoletta alla milanese della nonna con contorno di patatine fritte!',
        ],
        tempoPreparazione: 30,
        difficolta: 'Media',
        calorie: 400
    },
    {
        nome: 'Pizza',
        categoria: 'Primi piatti',
        ingredienti: [
            {nome: 'Farina', quantita: 500, unita: 'g'},
            {nome: 'lievito di birra', quantita: 2, unita: 'g'},
            {nome: 'Acqua', quantita: 250, unita: 'ml'},
            {nome: 'Sale fino', quantita: 3, unita: 'g'},
            {nome: 'pomodori pelati', quantita: 20, unita: 'g'},
            {nome: 'grana padano', quantita: 20, unita: 'g'},
            {nome: 'olio', quantita: 20, unita: 'ml'},
            {nome: 'mozzarella', quantita: 10, unita: 'g'},
            {nome: 'basilico', quantita: 2, unita: 'g'},
        ],
      
        immagine: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Eq_it-na_pizza-margherita_sep2005_sml.jpg/390px-Eq_it-na_pizza-margherita_sep2005_sml.jpg',
        preparazione: [
            'Per realizzare la pizza margherita iniziate dal prefermento: in una ciotola capiente mescolate la farina con il lievito , poi versate l acqua .',
            'Amalgamate gli ingredienti con movimenti delicati. Quando avrete ottenuto un composto grossolano e non vedrete più tracce di farina sul fondo della ciotola , copritela con pellicola e bucherellate con una forchetta, così che possa respirare . Riponete subito in frigorifero e lasciate maturare almeno per 24 ore, o comunque fino ad un massimo di 48 ore.',
            'Quando l acqua sarà stata completamente assorbita aggiungete il sale  e continuate a lavorare con movimenti dall alto verso il basso. Infine versate l olio  e impastate ancora per incorporarlo in modo uniforme . Se preferite potete realizzare questi passaggi in una planetaria, dotata di gancio.',
            'Quando avrete ottenuto una massa compatta trasferitevi sul piano di lavoro leggermente infarinato e lavorate l impasto energicamente fino ad ottenere una consistenza liscia e omogenea . Riponete nuovamente l impasto nella ciotola, coprite con un canovaccio umido e lasciate riposare per 15 minuti a temperatura ambiente .',
            'Trascorso questo tempo siete pronti per stagliare la pasta: dividete l impasto in 6 porzioni utilizzando un tarocco, poi roteate ciascuna sul piano di lavoro per sigillarla e arrotondarla . Adagiate man mano le palline nella cassetta per la lievitazione distanziandole fra loro. Chiudete con il coperchio (in alternativa potete utilizzare un vassoio leggermente infarinato coperto con pellicola o con un canovaccio umido) e lasciate lievitare per circa 3 ore.',
            'Nel frattempo preparate il condimento: versate i pelati in una ciotola e schiacciateli con le mani , poi condite con olio e basilico, spezzettando le foglioline con le mani .',
            'Trascorso il tempo di lievitazione  siete pronti per stendere i panetti: spolverizzate leggermente l impasto con la farina, poi schiacciatelo partendo dal centro e andando verso il bordo in alto, così da spingere l aria nel cornicione.',
            'Capovolgete l impasto  e procedete nello stesso modo, schiacciando sempre dal centro verso il bordo in alto. Ora allargate l impasto tenendolo fermo con una mano e tirandolo delicatamente con l altra , poi ribaltatelo sull altra mano e sbattetelo delicatamente sul piano. Quando avrete ottenuto un disco del diametro di circa 28 cm cospargete il pomodoro in modo uniforme, partendo dal centro e lasciando liberi i bordi.',
            'Trasferite la pizza sulla pala (se preferite potete stenderla direttamente sulla pala)  e cuocete a 250° (o alla massima temperatura) per 5-7 minuti, posizionandola direttamente sulla pietra refrattaria preriscaldata, posizionata nella parte alta del forno. Una volta cotta, sfornate e fate scivolare la pizza nel piatto . Guarnite con un paio di foglie di basilico e servite subito la vostra pizza margherita!'
         ],


        tempoPreparazione: 80,
        difficolta: 'media',
        calorie: 1200

    },
   
];


const categoriaSelect = document.createElement('select');
categoriaSelect.innerHTML = `
    <option value="all">Tutte le categorie</option>
    <option value="Antipasti">Antipasti</option>
    <option value="Primi piatti">Primi piatti</option>
    <option value="Secondi piatti">Secondi piatti</option>
    <option value="Contorni">Contorni</option>
    <option value="Dolci">Dolci</option>
`;
categoriaSelect.classList.add('categoria-select');


libreria.insertBefore(categoriaSelect, filtroSelect);


function mostraLibreriaRicette() {
    const searchTerm = ricercaInput.value.toLowerCase();
    const difficoltaFiltro = filtroSelect.value;
    const categoriaFiltro = categoriaSelect.value;

    const ricetteFiltrate = ricette.filter(ricetta => 
        ricetta.nome.toLowerCase().includes(searchTerm) &&
        (difficoltaFiltro === 'all' || ricetta.difficolta === difficoltaFiltro) &&
        (categoriaFiltro === 'all' || ricetta.categoria === categoriaFiltro)
    );

    listaRicette.innerHTML = ricetteFiltrate.map(ricetta => `
        <div class="ricetta">
            <h3>${ricetta.nome}</h3>
            <p><strong>Categoria:</strong> ${ricetta.categoria}</p>
            <img src="${ricetta.immagine}" alt="${ricetta.nome}">
            <p><strong>Ingredienti:</strong> ${ricetta.ingredienti.map(ing => `${ing.quantita} ${ing.unita} ${ing.nome}`).join(', ')}</p>
            <p><strong>Tempo di preparazione:</strong> ${ricetta.tempoPreparazione} minuti</p>
            <p><strong>Difficoltà:</strong> ${ricetta.difficolta}</p>
            <p><strong>Calorie per porzione:</strong> ${ricetta.calorie}</p>
            <button onclick="mostraDettagliRicetta('${ricetta.nome}')">Mostra Dettagli</button>
        </div>
    `).join('');
}


categoriaSelect.addEventListener('change', mostraLibreriaRicette);


function generaRicettaCasuale(porzioni) {
    const ricettaRandom = ricette[Math.floor(Math.random() * ricette.length)];
    const fattoreMoltiplicativo = porzioni / 4;
    
    const ingredientiAdjusted = ricettaRandom.ingredienti.map(ing => ({
        ...ing,
        quantita: Math.round(ing.quantita * fattoreMoltiplicativo * 10) / 10
    }));

    ricettaCasuale.innerHTML = `
        <h3>${ricettaRandom.nome}</h3>
        <p><strong>Categoria:</strong> ${ricettaRandom.categoria}</p>
        <img src="${ricettaRandom.immagine}" alt="${ricettaRandom.nome}">
        <p><strong>Ingredienti per ${porzioni} porzioni:</strong></p>
        <ul>
            ${ingredientiAdjusted.map(ing => `<li>${ing.quantita} ${ing.unita} ${ing.nome}</li>`).join('')}
        </ul>
        <p><strong>Tempo di preparazione:</strong> ${ricettaRandom.tempoPreparazione} minuti</p>
        <p><strong>Difficoltà:</strong> ${ricettaRandom.difficolta}</p>
        <p><strong>Calorie per porzione:</strong> ${ricettaRandom.calorie}</p>
        <h4>Preparazione:</h4>
        <ol>
            ${ricettaRandom.preparazione.map(step => `<li>${step}</li>`).join('')}
        </ol>
    `;
}


window.mostraDettagliRicetta = (nomeRicetta) => {
    const ricetta = ricette.find(r => r.nome === nomeRicetta);
    if (ricetta) {
        ricettaCasuale.innerHTML = `
            <h3>${ricetta.nome}</h3>
            <p><strong>Categoria:</strong> ${ricetta.categoria}</p>
            <img src="${ricetta.immagine}" alt="${ricetta.nome}">
            <p><strong>Ingredienti:</strong></p>
            <ul>
                ${ricetta.ingredienti.map(ing => `<li>${ing.quantita} ${ing.unita} ${ing.nome}</li>`).join('')}
            </ul>
            <p><strong>Tempo di preparazione:</strong> ${ricetta.tempoPreparazione} minuti</p>
            <p><strong>Difficoltà:</strong> ${ricetta.difficolta}</p>
            <p><strong>Calorie per porzione:</strong> ${ricetta.calorie}</p>
            <h4>Preparazione:</h4>
            <ol>
                ${ricetta.preparazione.map(step => `<li>${step}</li>`).join('')}
            </ol>
        `;
        generatore.classList.remove('nascondi');
        libreria.classList.add('nascondi');
    }
};
//non serve a niente lasciato perchè mantalitè del programmatore
window.stampaRicetta = (nomeRicetta) => {
    const ricetta = ricette.find(r => r.nome === nomeRicetta);
    if (ricetta) {
        const stampaFinestra = window.open('', '_blank');
        stampaFinestra.document.write(`
            <html>
                <head>
                    <title>Stampa Ricetta: ${ricetta.nome}</title>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; }
                        h1 { color: #333; }
                        img { max-width: 100%; height: auto; }
                    </style>
                </head>
                <body>
                    <h1>${ricetta.nome}</h1>
                    <p><strong>Categoria:</strong> ${ricetta.categoria}</p>
                    <img src="${ricetta.immagine}" alt="${ricetta.nome}">
                    <h2>Ingredienti:</h2>
                    <ul>
                        ${ricetta.ingredienti.map(ing => `<li>${ing.quantita} ${ing.unita} ${ing.nome}</li>`).join('')}
                    </ul>
                    <h2>Preparazione:</h2>
                    <ol>
                        ${ricetta.preparazione.map(step => `<li>${step}</li>`).join('')}
                    </ol>
                    <p><strong>Tempo di preparazione:</strong> ${ricetta.tempoPreparazione} minuti</p>
                    <p><strong>Difficoltà:</strong> ${ricetta.difficolta}</p>
                    <p><strong>Calorie per porzione:</strong> ${ricetta.calorie}</p>
                </body>
            </html>
        `);
        stampaFinestra.document.close();
        stampaFinestra.print();
    } //fino a qui tutto questi pezzo non fa niente
};

    window.salvaPreferita = (nomeRicetta) => {
        let preferite = JSON.parse(localStorage.getItem('ricettePreferite')) || [];
        if (!preferite.includes(nomeRicetta)) {
            preferite.push(nomeRicetta);
            localStorage.setItem('ricettePreferite', JSON.stringify(preferite));
            alert(`${nomeRicetta} è stata aggiunta alle tue ricette preferite!`);
        } else {
            alert(`${nomeRicetta} è già nelle tue ricette preferite.`);
        }
    };
});
//pure questo tolto dopo
